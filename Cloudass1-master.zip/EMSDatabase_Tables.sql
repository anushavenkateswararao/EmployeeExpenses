use Training_12DecMumbai

create schema EmployeeExpenses

create table EmployeeExpenses.Employee(
EmployeeId int  not null identity(1,1) primary key,
EmployeeName varchar(50) not null,
DateofBirth date,
Dateofjoin date,
DepartmentName varchar(20),
Location varchar(50),
EmailID varchar(240) not null unique
)

create table EmployeeExpenses.Expenses(

ReceiptDate date,
ReceiptSubmittedDate date,
ReceiptAmount money,
UploadReceipt varbinary(max),
Status varchar(20),
ApproveDate date,
EmployeeName varchar(20),
ReceiptNumber int not null identity(100,1) primary key,
EmployeeId int foreign key references  EmployeeExpenses.Employee(EmployeeId)

)



create table EmployeeExpenses.Supervisor(
SupervisorId int not null  identity(1000,1),
ReceiptNumber int foreign key references EmployeeExpenses.Expenses(ReceiptNumber),
SupervisorName varchar(20),
EmailID varchar(240) not null unique)


select * from EmployeeExpenses.Employee

select * from EmployeeExpenses.Expenses

select * from EmployeeExpenses.Supervisor
insert into EmployeeExpenses.Employee(EmployeeName,DateofBirth,Dateofjoin,DepartmentName,Location,EmailID)
values('Gayathri','11/18/1996','12/12/2018','csd','vikhroli','gayathri@gmail.com')

insert into EmployeeExpenses.Expenses(EmployeeName,EmployeeId) values('Gayathri',1)

insert into EmployeeExpenses.Supervisor(employeeName,SupervisorName,EmailID)
values('Gayathri','Anusha','anusha@gmail.com')